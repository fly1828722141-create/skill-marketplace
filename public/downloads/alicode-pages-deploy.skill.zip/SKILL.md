---
name: alicode-pages-deploy
description: Deploy static websites to AliCode Pages. Use when user wants to deploy HTML files, create static sites, fix 404 errors, or manage Pages deployments.
---

# AliCode Pages 部署指南

## 前置条件

- 仓库可见性：**公开**或**内部**（私有仓库无法使用 Pages）
- 入口文件：`index.html`
- Git 邮箱：阿里邮箱（如 `xxx@alibaba-inc.com`）

## 5 步部署流程

### 1. 准备仓库

```bash
git clone https://code.alibaba-inc.com/{namespace}/{repo}.git
cd {repo}
git config user.email "your-email@alibaba-inc.com"
```

### 2. 添加文件

```bash
# HTML 作为入口
cp your-file.html index.html

# 图片等资源
mkdir -p images
cp *.png images/

git add .
git commit -m "初始化站点"
git push origin main
```

### 3. 创建部署配置

创建 `.aoneci/deploy-pages.yaml`：

```yaml
name: deploy-pages
triggers:
  push:
jobs:
  deploy:
    image: alios-8u
    steps:
      - uses: checkout
      - uses: deploy-pages
        inputs:
          deploy-dir: ./
          production-branch: main
```

```bash
git add .aoneci/deploy-pages.yaml
git commit -m "添加 Pages 配置"
git push origin main
```

### 4. 启用 Pages

1. 访问 `https://code.alibaba-inc.com/{namespace}/{repo}/pages`
2. 点击 **启用 Pages**
3. 配置：
   - 站点名称：`{your-site-name}`
   - 部署分支：`main`
   - 构建命令：（留空）
   - 输出目录：（留空）
4. 点击 **保存**

### 5. 验证部署

```bash
# 等待 3-5 分钟后验证
curl -I https://{your-site-name}.io.alibaba-inc.com/
# 期望返回 HTTP 200
```

访问：`https://{your-site-name}.io.alibaba-inc.com/`

## 图片管理

| 规范 | 正确 | 错误 |
|------|------|------|
| 路径 | `images/xxx.png` | `/absolute/path.png` |
| 引用 | `<img src="images/xxx.png">` | `<img src="http://...">` |
| 目录 | 统一放 `images/` | 散放在根目录 |

## 问题排查

### 部署失败快速处理（推荐）

**当发现部署失败时，优先尝试重新部署（90%的问题可通过重试解决）：**

```bash
# 方法1：添加 README 触发重新部署（推荐）
cat > README.md << 'EOF'
# 站点说明
访问地址：https://{your-site-name}.io.alibaba-inc.com/
EOF
git add . && git commit -m "触发重新部署" && git push

# 方法2：修改任意文件后推送
echo "# deploy $(date)" >> README.md
git add . && git commit -m "触发重新部署" && git push

# 方法3：空提交（不推荐，仅用于测试）
git commit --allow-empty -m "触发重新部署" && git push
```

**重新部署后等待 3-5 分钟，然后验证站点是否可访问。**

### 部署失败深度排查（重试无效时使用）

如果重新部署后仍然失败，按以下步骤排查：

1. **检查仓库可见性**：确认仓库为"公开"或"内部"（私有仓库无法使用 Pages）
   - 修改路径：仓库首页 → 设置 → 基本信息 → 公开性

2. **检查配置文件**：确认 `.aoneci/deploy-pages.yaml` 存在且格式正确
   - 常见错误：缩进错误、缺少冒号、中文标点等

3. **查看 CI 日志**：
   - 访问 `https://code.alibaba-inc.com/{namespace}/{repo}/-/pipelines`
   - 点击失败的任务名称（如 `deploy-pages`）
   - 查看具体错误信息

4. **常见失败原因**：
   - 仓库为私有（最常见）
   - YAML 语法错误
   - 站点名称已被占用
   - 网络或权限问题

### 404 错误

| 症状 | 原因 | 解决 |
|------|------|------|
| 站点 404 | 仓库私有 | 改为"公开"或"内部" |
| 站点 404 | 缺少配置 | 添加 `.aoneci/deploy-pages.yaml` |
| 站点 404 | 部署中 | 等待 3-5 分钟 |
| 站点 404 | 名称冲突 | 更换站点名称 |
| 站点 404 | CI 任务失败 | 查看日志，修复后重新推送 |

### 图片不显示

| 症状 | 原因 | 解决 |
|------|------|------|
| 裂图 | 路径错误 | 使用 `images/xxx.png` |
| 裂图 | 未上传 | `git add images/` 后推送 |
| 裂图 | 大小写 | 检查文件名大小写 |

### Git 推送失败

```bash
# 邮箱不合法
git config user.email "xxx@alibaba-inc.com"
```

### 重新部署方法

当部署失败或需要更新站点时，通过以下任一方式触发重新部署：

```bash
# 方法1：添加 README.md 触发重新部署（推荐，最稳定）
cat > README.md << 'EOF'
# 站点说明
访问地址：https://{your-site-name}.io.alibaba-inc.com/
EOF
git add . && git commit -m "触发重新部署" && git push

# 方法2：追加内容到 README（快速触发）
echo "# deploy $(date)" >> README.md
git add . && git commit -m "触发重新部署" && git push

# 方法3：修改任意文件内容
# 编辑 index.html 或配置文件后推送

# 方法4：空提交（不推荐，仅用于测试）
git commit --allow-empty -m "触发重新部署" && git push
```

**重新部署后验证**：
```bash
# 等待 3-5 分钟后检查
curl -I https://{your-site-name}.io.alibaba-inc.com/
# 期望返回 HTTP 200
```

## 完整示例

```bash
# 1. 克隆仓库
git clone https://code.alibaba-inc.com/ai-shangfan-code/my-report.git
cd my-report

# 2. 配置 Git 邮箱（必须使用阿里邮箱）
git config user.email "your-name@alibaba-inc.com"

# 3. 添加文件
cp ~/Desktop/report.html index.html
mkdir -p images && cp ~/Desktop/*.png images/

# 4. 创建配置
mkdir -p .aoneci
cat > .aoneci/deploy-pages.yaml << 'EOF'
name: deploy-pages
triggers:
  push:
jobs:
  deploy:
    image: alios-8u
    steps:
      - uses: checkout
      - uses: deploy-pages
        inputs:
          deploy-dir: ./
          production-branch: main
EOF

# 5. 推送
git add . && git commit -m "初始化" && git push

# 6. 在 AliCode 启用 Pages
# 访问: https://code.alibaba-inc.com/ai-shangfan-code/my-report/pages
# 点击"启用 Pages"，填写站点名称（如 my-report），保存

# 7. 等待 3-5 分钟后验证
# 访问: https://my-report.io.alibaba-inc.com/
```

## 边界情况处理

### 分支不是 main

如果默认分支是 `master` 或其他名称：
1. 修改 `.aoneci/deploy-pages.yaml` 中的 `production-branch: master`
2. 或在推送时指定分支：`git push origin master`

### 站点名称规范

- 仅支持小写字母、数字、连字符（-）
- 不能以连字符开头或结尾
- 长度 3-63 个字符
- 示例：`my-site`、`project2024`、`team-docs`

### 仓库可见性修改

1. 访问仓库首页 → 点击"设置"标签
2. 在"基本信息"中找到"公开性"
3. 选择"公开：集团所有正式员工登录可浏览"
4. 点击保存

## 最佳实践

1. **入口文件**：始终用 `index.html`
2. **图片目录**：统一放 `images/`
3. **路径**：相对路径 `images/xxx.png`
4. **可见性**：创建时选"公开"或"内部"
5. **验证**：部署后用 `curl -I` 检查状态
6. **失败处理**：**优先尝试重新部署**（添加 README 触发），90%的问题可通过重试解决，无需排查
7. **耐心等待**：首次部署或重新部署后，等待 3-5 分钟再验证

## 快速部署检查清单

- [ ] 仓库可见性为"公开"或"内部"
- [ ] 包含 `index.html` 入口文件
- [ ] 已创建 `.aoneci/deploy-pages.yaml` 配置
- [ ] 已在 AliCode Pages 页面启用并填写站点名称
- [ ] 推送代码后等待 3-5 分钟
- [ ] 如失败，添加 README 触发重新部署
- [ ] 再次等待 3-5 分钟后验证
